$(document).ready(function () {

  $('#Janel').mouseover(function () {
    {
      $('.fullimage').attr("src", '../images/pro_1.png');
      $('#janell').addClass("active");
    }
  });

  $('#TippiShorter').mouseover(function () {
     {
      $('.fullimage').attr("src", '../images/pro_2.png');
      $('#tippishorter').addClass("active");
    }
  });
  $('#IanMichael').mouseover(function () {
     {
      $('.fullimage').attr("src", '../images/pro_3.png');
      $('#ianmichael').addClass("active");
    }
  });
  $('#Allen').mouseover(function () {
    {
      $('.fullimage').attr("src", '../images/pro_4.png');
      $('#allen').addClass("active");
     
    }
  });
  $('#Ricardo').mouseover(function () {
   {
      $('.fullimage').attr("src", '../images/pro_5.png');
      $('#ricardo').addClass("active");
    }
  });
  $('#Janel,#TippiShorter,#IanMichael,#Allen,#Ricardo').mouseout(function () {
    //$('.container__division').css("border-top", 'none');
    $('.fullimage').attr("src", '../images/pros.png');
     $('.container__division').removeClass("active");
  });

$('.wax, .product').mouseover(function () {

      $('.wax').addClass("make");
	  $('.product').addClass('producthover');
  });
$('.wax, .product').mouseout(function () {

     	 $('.wax').removeClass("make");
	$('.product').removeClass('producthover');
  });
$(' .skincare, .product-face').mouseover(function () {

      $(' .skincare').addClass("make");
	  $(' .product-face').addClass('product-facehover');
  });
$(' .skincare, .product-face').mouseout(function () {

     	 $('.skincare').removeClass("make");
	$(' .product-face').removeClass('product-facehover');
  });

});