import React,{Component} from 'react';
import ReactDOM from 'react-dom';
//import { BackgroundOption} from './component/BackgroundOption';
export class BackgroundOption extends Component
{
    constructor(props)
    {
    super (props)
    this.state={bgcolor:"" }
    this.handleChange=this.handleChange.bind(this);
   
    }
   
handleChange (event) 
{ 
    let col=event.target.value;
    this.setState({bgcolor:col})
}
       
        

           
    render()
    {
        return(
            <div>
                
                <input type="text" value={this.state.bgcolor}
                onChange={this.handleChange}/>
              <Contacts/>
           
               
             </div>
        )
           }           }        
                                 
        
        