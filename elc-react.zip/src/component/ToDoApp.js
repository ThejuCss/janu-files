import React, { Component } from 'react';
export class ToDoApp extends Component {

constructor(props) {

super();

this.state = {

data: [],

value: "",

butt: "Add",

updateStatus: false

};

this.handleChange = this.handleChange.bind(this);

this.add = this.add.bind(this);

this.remove = this.remove.bind(this);

this.update = this.update.bind(this);

this.replace = this.replace.bind(this);

}

handleChange(event) {

let val = event.target.value;

this.setState({ value: val })

}

add() {

let val = this.state.value;

let arr = this.state.data;

arr.push(val);

this.setState({ data: arr, value: ""
});
alert("Done Successfully")
}

remove(id) {

    this.setState(prevState => ({
    
    data: prevState.data.filter(work =>
    work != id)
    
    }));
  
    }

update(id) {

this.setState({ value: id, butt: "Update",
updateStatus: true });
this.remove(id);

}

replace(id) {

this.add();

this.setState({ value: "", updateStatus: false,
butt: "Add" })

}

    

render() {

return (

<div>

<h1>To Do App</h1>

<input type="text" onChange={this.handleChange}
value={this.state.value} />

<button onClick={(this.state.butt
=== "Add") ? this.add : this.replace}>{this.state.butt}</button>

{(!this.state.updateStatus) ?

this.state.data.map((work, i) =>

<li ref={this.input}>{work}
<button onClick={this.update.bind(this,
work)}>Update</button><button
onClick={this.remove.bind(this, work)}
>Delete</button></li>

) : ""}

</div>

);

}

}

