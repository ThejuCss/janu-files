import React,{Component} from 'react';
import ReactDOM from 'react-dom';

//import {HotelBookings} from './component/HotelBookings';
 export class HotelBookings extends Component{
constructor(props){
    super(props)
    this.state = {firstname:"",
    lastname:"",
    address: "",
    persons:0,
    veg: "",
    nonveg:"",
    place:""
    };
    this.upperCase = this.upperCase.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.submit = this.submit.bind(this);}
    
  
    
    
    upperCase(event){
    
    this.setState({[event.target.name]:event.target.value.toUpperCase()});
    
    }
    
    handleChange(event){
    
    this.setState({[event.target.name]:event.target.value});
    
    console.log(this.state);
    
    }
    
    submit(event){
    
    alert('Thank You! Name:' + this.state.firstname +this.state.lastname 
    + 'Number of persons:' + this.state.persons  +'Food service selected!'+
    this.state.nonveg +  'Place:' + this.state.place);
    
    event.preventDefault();
    
    }
    reset(event) {
        this.setState(this.baseState)
      }
    
    
    render(){
    
    return(
    
    <div class="Form-section">
    
    <form onSubmit={this.submit}>
    <div class="header">
    <h1>HOTEL BOOKING</h1>
    </div>
    <div class="first-name">
    <label>Firstname:</label>
    
    <input type="text" placeholder=" firstName"
    name="firstname" value={this.state.firstname}
    onChange={this.upperCase}/><br/><br/>
    </div>
    <div class="last-name">
    <label>Lastname:</label>
    
    <input type="text" placeholder=" lastName"
    name="lastname" value={this.state.lastname}
    onChange={this.upperCase}/><br/><br/>
    </div><div class="address">
    <label>Address:</label>
    
    <textarea placeholder="Address" name="address"
    onChange={this.handleChange}></textarea><br/><br/>
    </div><div class="no-of-persons">
    <label>Number of persons</label>
    
    <input type="number" name="persons" min="1"
    onChange={this.handleChange}/><br/><br/>
    </div><div class="food-service">
    <label> want food service? veg</label>
    
    <input type="checkbox" name="veg" onChange={this.handleChange}/>
    <label>non-veg</label>
    <input type="checkbox" name="nonveg" onChange={this.handleChange}/><br/><br/>
    <label>Choose the Place you want?</label>
    </div>
    <div class="location">
    <select name="place" onChange={this.handleChange}>
    
    <option>Select  Place</option>
    
    <option>chennai</option>
    
    <option>hyderabad</option>
    
    <option>bangalore</option>
    
    <option>new delhi</option>
    
    <option>jharkand</option>
    
    </select><br/><br/>
    </div><div>
    <input type="date"/><br/><br/></div>
    <div>
    <input type="submit" />
    <input type="reset"/></div>
    </form>
    </div>
    
    );
    
    }
    
 }
