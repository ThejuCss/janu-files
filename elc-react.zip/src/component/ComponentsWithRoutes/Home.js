import React from 'react'
export class Home extends React.Component{
        render()
            {
                    return(
                    <div>
                        <h1>HOME</h1>
                    </div>
                    );
               }
}