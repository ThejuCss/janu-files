import React from 'react'
export class ContactUs extends React.Component{
        render()
            {
                    return(
                    <div>
                        <h1>ContactUs</h1>
                    </div>
                    );
               }
}