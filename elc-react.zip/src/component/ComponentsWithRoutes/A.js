import React from 'react'
export class A extends React.Component{
        render()
            {
                    return(
                    <div>
                        <h1>404 error</h1>
                    </div>
                    );
               }
}