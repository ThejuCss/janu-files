import React,{Component} from 'react';
import ReactDOM from 'react-dom';

import { HotelBookings} from './component/HotelBookings';

//import {HotelBookings } from './component/HtelBookings';
import * as serviceWorker from './serviceWorker';


ReactDOM.render(<HotelBookings/>, document.getElementById('root'));

serviceWorker.unregister();
