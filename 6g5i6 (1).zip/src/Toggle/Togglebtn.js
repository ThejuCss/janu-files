import React from "react";

class Togglebtn extends React.Component {
  constructor(props) {
    super();
    this.state = { status: true };
    this.toggle = this.toggle.bind(this);
  }
  toggle() {
    this.state.status = !this.state.status;
    this.setState({ status: this.state.status });
  }
  render() {
    return (
      <div>
        <h1>Toggling values</h1>
        <button onClick={this.toggle}>
          {this.state.status ? "ON" : "OFF"}
        </button>
      </div>
    );
  }
}
export default Togglebtn;
