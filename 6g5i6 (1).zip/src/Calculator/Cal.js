import React from "react";

class Calci extends React.Component {
  render() {
    return (
      <div>
        <input
          type="text"
          name="num1"
          value={this.props.num1}
          onChange={this.props.handleChange}
        />
        <input
          type="text"
          name="num2"
          value={this.props.num2}
          onChange={this.props.handleChange}
        />
      </div>
    );
  }
}
export default Calci;
