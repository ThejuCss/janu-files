import React from "react";
import ReactDOM from "react-dom";
//import Calcilogic from "./Calculator/Calcilogic";
//import Increment from "./Numberinc/Increment";
//import Details from "./Employee/Details";
//import Currenttime from "./Time/Currenttime";
//import Changes from "./ColorChange/Changes";
//import Highlights from "./Experience/Highlights";
//import Form from "./Signupform/Form";
import Togglebtn from "./Toggle/Togglebtn";

const rootElement = document.getElementById("root");
ReactDOM.render(<Togglebtn />, rootElement);
