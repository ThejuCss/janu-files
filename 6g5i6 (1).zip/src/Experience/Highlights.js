import React from "react";

class Highlights extends React.Component {
  constructor(props) {
    super(props);
    this.state = { exp1: "", exp2: "", border1: "", border2: "" };
    this.handleChange = this.handleChange.bind(this);
    this.highlight = this.highlight.bind(this);
  }
  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
    console.log(this.state);
  }
  highlight() {
    parseInt(this.state.exp1) > parseInt(this.state.exp2)
      ? this.setState({ border1: "#ccffcc", border2: "" })
      : this.setState({ border2: "#ccffcc", border1: "" });
    setTimeout(
      () => this.setState({ border1: "", border2: "", exp1: "", exp2: "" }),
      2000
    );
  }
  render() {
    var div1_style = { background: this.state.border1 };
    var div2_style = { background: this.state.border2 };
    return (
      <div>
        <input type="text" placeholder="FirstEmployee" disabled />
        <input type="text" placeholder="Name" style={div1_style} />
        Exp:
        <input
          type="text"
          name="exp1"
          value={this.state.exp1}
          onChange={this.handleChange}
        />
        <br />
        <input type="text" placeholder="SecondEmployee" disabled />
        <input type="text" placeholder="Name" style={div2_style} />
        Exp:
        <input
          type="text"
          name="exp2"
          value={this.state.exp2}
          onChange={this.handleChange}
        />
        <br />
        <button onClick={this.highlight}>Highlight</button>
      </div>
    );
  }
}
export default Highlights;
