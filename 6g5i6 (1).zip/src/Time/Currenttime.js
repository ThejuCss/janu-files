import React from "react";

class Currenttime extends React.Component {
  constructor(props) {
    super(props);
    this.state = { date: "" };
  }
  componentWillMount() {
    let hour = new Date().getHours();
    let min = new Date().getMinutes();
    let sec = new Date().getSeconds();
    this.setState({ date: hour + ":" + min + ":" + sec });
  }
  render() {
    return <div>It is {this.state.date}</div>;
  }
}
export default Currenttime;
