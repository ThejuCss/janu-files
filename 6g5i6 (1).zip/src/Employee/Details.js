import React from "react";
import Table from "./Table";

class Details extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      employee: [
        { name: "Gowsalya", id: "119114", position: "Engineer" },
        { name: "Shilpa", id: "119112", position: "Engineer" },
        { name: "Ramya", id: "119231", position: "Analyst" }
      ]
    };
  }
  render() {
    return <Table employee={this.state.employee} />;
  }
}
export default Details;
