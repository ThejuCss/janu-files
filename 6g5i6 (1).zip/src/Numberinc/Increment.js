import React from "react";

class Increment extends React.Component {
  constructor(props) {
    super(props);
    this.state = { num: 0, bgrnd: "" };
    this.inc = this.inc.bind(this);
  }
  inc() {
    this.setState({
      num: this.state.num + 1,
      bgrnd: this.state.num % 2 === 0 ? "green" : "red"
    });
  }
  render() {
    let font_color = { color: this.state.bgrnd };
    return (
      <div style={font_color}>
        <p>The current value is : {this.state.num} </p>
        <button onClick={this.inc}>Increae</button>
      </div>
    );
  }
}
export default Increment;
