import React from "react";

class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      pwd: "",
      status: true,
      border: "red",
      width: 2
    };
    this.show = this.show.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
    this.state.email !== "" && this.state.pwd !== ""
      ? this.setState({ status: false, border: "black" })
      : this.setState({ status: true, border: "red" });
  }
  show() {
    alert(
      "Signed up with Email : " +
        this.state.email +
        " and Password : " +
        this.state.pwd
    );
  }
  render() {
    var input_border = { border: this.state.border + " 1px solid" };
    return (
      <div>
        <h1>Signup Form</h1>
        <input
          type="email"
          name="email"
          value={this.state.email}
          placeholder="Email"
          onChange={this.handleChange}
          style={input_border}
        />
        <br />
        <input
          type="password"
          name="pwd"
          value={this.state.pwd}
          placeholder="Passsword"
          onChange={this.handleChange}
          style={input_border}
        />
        <br />
        <button type="submit" onClick={this.show} disabled={this.state.status}>
          Submit
        </button>
      </div>
    );
  }
}
export default Form;
