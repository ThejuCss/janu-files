import React from "react";

class Colorfields extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div>
        <input type="text" onChange={this.props.handleChange} />
      </div>
    );
  }
}
export default Colorfields;
