import React from "react";
import Colorfields from "./Colorfield";

class Changes extends React.Component {
  constructor(props) {
    super(props);
    this.state = { Color: "" };
    this.handleChange = this.handleChange.bind(this);
    this.changeColor = this.changeColor.bind(this);
  }
  handleChange(event) {
    this.state.Color = event.target.value;
  }
  changeColor() {
    this.setState({ Color: this.state.Color });
  }
  render() {
    let h1_style = { color: this.state.Color };
    return (
      <div>
        <Colorfields handleChange={this.handleChange} />
        <h1 style={h1_style}>REACT JS SESSION</h1>
        <button onClick={this.changeColor}>Change color</button>
      </div>
    );
  }
}
export default Changes;
