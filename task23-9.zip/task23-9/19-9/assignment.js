
$(window).on('load', function() {

$('.js-product-list').slick({
	
	 infinite: false,
  variableWidth: false,
  adaptiveHeight: false,
  slidesToShow: 3,
  slidesToScroll: 1,
  arrows: true,

}); 

 
$(".accordion").click(function() {
    if ($('.js-product-kit-container').is(':visible')) {
      $(".js-product-kit-container").slideUp(300);
      $(".plusminus").text('>');
    }
    if ($(this).next(".js-product-kit-container").is(':visible')) {
      $(this).next("..js-product-kit-container").slideUp(300);
      $(this).children(".plusminus").text('>');
    } else {
      $(this).next(".js-product-kit-container").slideDown(300);
	  $('.js-product-list').slick('setPosition');
      $(this).children(".plusminus").text('v');
    }
  });
   $(".js-product-btn-1").click(function () {
    $('.imageSwitch-1').each(function () {
        string = $(this).text('select');
        $(this).html('<img src="check.png" alt="' + string + '" />');
    });
});
 $(".js-product-btn-2").click(function () {
    $('.imageSwitch-2').each(function () {
        string = $(this).text('select');
        $(this).html('<img src="check.png" alt="' + string + '" />');
    });
});
 $(".js-product-btn-3").click(function () {
    $('.imageSwitch-3').each(function () {
        string = $(this).text('select');
        $(this).html('<img src="check.png" alt="' + string + '" />');
    });
});
 $(".js-product-btn-4").click(function () {
    $('.imageSwitch-4').each(function () {
        string = $(this).text('select');
        $(this).html('<img src="check.png" alt="' + string + '" />');
    });
});

})

