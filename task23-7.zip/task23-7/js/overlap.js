$(document).ready(function () {

  $('#Janel').mouseover(function () {
    var flag = 0;
    if (flag == 0) {
      $('.fullimage').attr("src", '../images/pro_1.png');
      $('#janell').addClass("active");
    }
  });

  $('#TippiShorter').mouseover(function () {
    var flag = 0;
    if (flag == 0) {
      $('.fullimage').attr("src", '../images/pro_2.png');
      $('#tippishorter').addClass("active");
    }
  });
  $('#IanMichael').mouseover(function () {
    var flag = 0;
    if (flag == 0) {
      $('.fullimage').attr("src", '../images/pro_3.png');
      $('#ianmichael').addClass("active");
    }
  });
  $('#Allen').mouseover(function () {
    var flag = 0;
    if (flag == 0) {
      $('.fullimage').attr("src", '../images/pro_4.png');
      $('#allen').addClass("active");
     
    }
  });
  $('#Ricardo').mouseover(function () {
    var flag = 0;
    if (flag == 0) {
      $('.fullimage').attr("src", '../images/pro_5.png');
      $('#ricardo').addClass("active");
    }
  });
  $('#Janel,#TippiShorter,#IanMichael,#Allen,#Ricardo').mouseout(function () {
    //$('.container__division').css("border-top", 'none');
    $('.fullimage').attr("src", '../images/pros.png');
     $('container__division').removeClass("active");
  });

});