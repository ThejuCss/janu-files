$(document).ready(function () {

  $('#Janel').mouseover(function () {
    {
      $('.fullimage').attr("src", '../images/pro_1.png');
      $('#janell').addClass("active");
    }
  });

  $('#TippiShorter').mouseover(function () {
     {
      $('.fullimage').attr("src", '../images/pro_2.png');
      $('#tippishorter').addClass("active");
    }
  });
  $('#IanMichael').mouseover(function () {
     {
      $('.fullimage').attr("src", '../images/pro_3.png');
      $('#ianmichael').addClass("active");
    }
  });
  $('#Allen').mouseover(function () {
    {
      $('.fullimage').attr("src", '../images/pro_4.png');
      $('#allen').addClass("active");
     
    }
  });
  $('#Ricardo').mouseover(function () {
   {
      $('.fullimage').attr("src", '../images/pro_5.png');
      $('#ricardo').addClass("active");
    }
  });
  $('#Janel,#TippiShorter,#IanMichael,#Allen,#Ricardo').mouseout(function () {
   
    $('.fullimage').attr("src", '../images/pros.png');
     $('.container__division').removeClass("active");
  });

$('.wax, .product').mouseover(function () {

      $('.wax').addClass("make");
	  $('.product').addClass('producthover');
  });
$('.wax, .product').mouseout(function () {

     	 $('.wax').removeClass("make");
	$('.product').removeClass('producthover');
  });
$(' .skincare, .product-face').mouseover(function () {

      $(' .skincare').addClass("make");
	  $(' .product-face').addClass('product-facehover');
  });
$(' .skincare, .product-face').mouseout(function () {

     	 $('.skincare').removeClass("make");
	$(' .product-face').removeClass('product-facehover');
  });
$(' .wax, .products-candle').mouseover(function () {

      $(' .wax').addClass("make");
	  $(' .products-candle').addClass('products-candlehover');
  });
$(' .wax, .products-candle').mouseout(function () {

     	 $('.wax').removeClass("make");
	$(' .products-candle').removeClass('products-candlehover');
  });
$(' .shampure, .products-shampure').mouseover(function () {

      $(' .shampure').addClass("make");
	  $(' .products-shampure').addClass('products-shampurehover');
  });
$(' .shampure, .products-shampure').mouseout(function () {

     	 $('.shampure').removeClass("make");
	$(' .products-shampure').removeClass('products-shampurehover');
  });
  $(' .remedy, .products-remedy').mouseover(function () {

      $(' .remedy').addClass("make");
	  $(' .products-remedy').addClass('products-remedyhover');
  });
$(' .remedy, .products-remedy').mouseout(function () {

     	 $('.remedy').removeClass("make");
	$(' .products-remedy').removeClass('products-remedyhover');
  });
  

});